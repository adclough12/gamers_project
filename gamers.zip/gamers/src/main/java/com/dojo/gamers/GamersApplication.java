package com.dojo.gamers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GamersApplication {

	public static void main(String[] args) {
		SpringApplication.run(GamersApplication.class, args);
	}

}
