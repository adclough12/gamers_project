package com.dojo.gamers.models;

public class User {

}
