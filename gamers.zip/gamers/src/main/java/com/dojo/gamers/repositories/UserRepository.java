package com.dojo.gamers.repositories;

public interface UserRepository {

}
